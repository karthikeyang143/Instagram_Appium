package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class ForgotPasswordPage extends BasePage{

	public ForgotPasswordPage(AppiumDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}


	By hdrFindYourAccount_Title = By.id("com.instagram.android:id/field_title");
	By txtEmailOrPhoneNumber = By.id("com.instagram.android:id/fragment_lookup_edittext");
	By btnNext = By.id("com.instagram.android:id/button_text");
	By lnkResetByEmail = By.id("com.instagram.android:id/fragment_user_password_recovery_button_email_reset");
	By lnkResetBySMS = By.id("com.instagram.android:id/fragment_user_password_recovery_button_sms_reset");
	By lblEmailSuccessMessage = By.id("com.instagram.android:id/fragment_user_password_recovery_textview_request_sent");
	By lblSMS_SuccessMessagePopup = By.id("com.instagram.android:id/igds_headline_headline");
	By btnResetPwd_OK = By.id("com.instagram.android:id/primary_button");
	

	/**Page Methods*/
    public void ResetMyPassword_FillDetails(String strInput) {
    	try
		{
			System.out.println("inside ResetMyPassword_FillDetails method");
			
			if(verifyMyElementDisplay(txtEmailOrPhoneNumber, "min", "Find your account inout Textbox"))
			{
				Test.log(LogStatus.PASS,Test.addScreenCapture(captureScreenshot(driver))+ "Find your account screen is displayed");
				Reporter.log("Find your account screen is displayed");
				SendKeysToElement(txtEmailOrPhoneNumber, "min", strInput, "EmailOrPhoneNumber TextBox");
				ClickElement(btnNext, "min", "Next Button");
			}		
		}
		catch(Exception e)
		{
			Reporter.log("Exception in ResetMyPassword_FillDetails, "+e.getMessage());
		}
    }
    
    public ForgotPasswordPage ResetMyPassword_Email(String strInput) {
    	
    	System.out.println("TEST");
    	try {
			ResetMyPassword_FillDetails(strInput); 
			if(verifyMyElementDisplay(lnkResetByEmail, "min", "Send an Email Link"))
			{
				ClickElement(lnkResetByEmail, "min", "Send an Email Link");
				verifyMyElementDisplay(lblEmailSuccessMessage, "min", "Success Message - Reset Password Request");	
			}
    	}
    	catch(Exception e)
    	{
    		Reporter.log("Exception in ResetMyPassword_Email, "+e.getMessage());
    	}
        return this;
    }
    
public ForgotPasswordPage ResetMyPassword_SMS(String strInput) 
	{
    	
	try {
		ResetMyPassword_FillDetails(strInput);		  
		if(verifyMyElementDisplay(lnkResetBySMS, "min", "Send an SMS Message Link"))
		{
			ClickElement(lnkResetBySMS, "min", "Send an SMS Message Link");
			if(verifyMyElementDisplay(lblSMS_SuccessMessagePopup, "min", "Success Message - Reset Password Request"))
			{			
				ClickElement(btnResetPwd_OK, "min", "OK Button"); 
			}
			
		}
    	}
    	catch(Exception e)
    	{
    		Reporter.log("Exception in ResetMyPassword_SMS, "+e.getMessage());
    	}
        return this;
    }
    
    public ForgotPasswordPage VerifyFindYourAccountFieldDisplay() {
    	verifyMyElementDisplay(hdrFindYourAccount_Title, "min", "Forgot Password - Find your account Header");
    	verifyMyElementDisplay(txtEmailOrPhoneNumber, "min", "Find your account - Input");
    	verifyMyElementDisplay(btnNext, "min", "Find your account - Next Button");
        return this;
    }
    
}
