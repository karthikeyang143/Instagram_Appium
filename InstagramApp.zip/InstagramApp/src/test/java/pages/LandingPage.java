package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class LandingPage extends BasePage{
	/**Constructor*/
    public LandingPage(AppiumDriver driver) {
        super(driver);
    }
    
    By imgLogo = By.id("com.instagram.android:id/logo");
    By btnLogin = By.id("com.instagram.android:id/log_in_button");
    By lnkSignup = By.id("com.instagram.android:id/sign_up_with_email_or_phone");
        
    public LandingPage VerifyLaunchApp()
   	{    	
    	try
   		{   			
   			System.out.println("inside VerifyLaunchApp");
   			if(verifyMyElementDisplay(imgLogo, "min", "Logo"))
   	    	{
   				Test.log(LogStatus.PASS,Test.addScreenCapture(captureScreenshot(driver))+ "Application is launched successfully");
   				Reporter.log("Application is launched successfully");
   			}
   			else
			{
				Test.log(LogStatus.FAIL,Test.addScreenCapture(captureScreenshot(driver))+ "Application is NOT launched");
				Reporter.log("Logo is NOT available, Failed to launch application");
			}
   		}
   		catch(Exception e)
   		{
   			Reporter.log("Exception in VerifyLaunchApp, "+e.getMessage());
   		}
   		return this;
   	}
    public LoginPage VerifyLandingPageLogo() {
    	verifyMyElementDisplay(imgLogo, "min", "Logo");    	
        return new LoginPage(driver);
    }
    
    public LoginPage VerifyLoginLink() {
    	verifyMyElementDisplay(btnLogin, "min", "Login link");    	
        return new LoginPage(driver);
    }
    
    public LoginPage GoToLoginPage() {
    	ClickElement(btnLogin, "min", "Login link");    	
        return new LoginPage(driver);
    }
    
    public SignupPage VerifySingupLink() {    	
    	verifyMyElementDisplay(lnkSignup, "min", "Signup link");    	
        return new SignupPage(driver);
    }   
    
    public SignupPage GoToSignupPage() {
    	ClickElement(lnkSignup, "min", "Sign up link");  
        return new SignupPage(driver);
    }
    
}
