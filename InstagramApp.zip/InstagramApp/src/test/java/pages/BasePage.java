package pages;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.google.common.io.Files;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import testcases.CommonTest;

public class BasePage extends CommonTest{
	
	public static AppiumDriver driver;
  	//public static AppiumDriver driver;
  	public static ExtentTest Test;
  	public static ExtentReports Report;
  		
  //Constructor
    public BasePage(AppiumDriver driver) {
        this.driver = driver;
    }    

	public static void AppiumSetup()
	{
		try
		{
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "8.0.0");
		caps.setCapability(MobileCapabilityType.DEVICE_NAME, "SM A520F");
		caps.setCapability(MobileCapabilityType.UDID, "5200c0bfc0b53545");
		caps.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 60);
		caps.setCapability(MobileCapabilityType.NO_RESET, "true");
		caps.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, "com.instagram.android");
		caps.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, "com.instagram.mainactivity.LauncherActivity");
		//caps.setCapability(MobileCapabilityType.APP, "C:\\\\WORKSPACE\\\\EclipseWorkspace\\\\Instagram.apk");
		
		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		driver=new AppiumDriver<MobileElement>(url,caps);		
		
		}
		catch(Exception e)
		{
			System.out.println("Exception in setup");
		}	
	
	}
  
	public static void startExtentReport()
	{
		Report = new ExtentReports(System.getProperty("user.dir")+"\\test-output\\ExtentReports\\AutomationResults.html");
		Test = Report.startTest("InstagramAutomation");
	}  	 

	public static void endMyTest()
	{
  		Report.endTest(Test);
  		Report.flush();
  		driver.close();
  		driver.quit();
	}
  		
    
  	
}
