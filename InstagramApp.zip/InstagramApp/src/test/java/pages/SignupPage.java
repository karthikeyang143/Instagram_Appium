package pages;

import java.util.List;

import org.jsoup.Connection.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class SignupPage extends BasePage{

	public SignupPage(AppiumDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	By lnkSignup = By.id("com.instagram.android:id/sign_up_with_email_or_phone");
	By hdrEmailAddres = By.xpath("//android.widget.LinearLayout[@content-desc=\"Email address\"]/android.widget.TextView");
	By txtEmail = By.id("com.instagram.android:id/email_field");
	By btnNext = By.id("com.instagram.android:id/button_text");
	By hdrEnterConfirmationCode = By.id("com.instagram.android:id/title_text");
	By txtEnterConfirmationCode = By.id("com.instagram.android:id/confirmation_code");
	
	By txtFullname = By.id("com.instagram.android:id/full_name");
	By txtPassword = By.id("com.instagram.android:id/password");
	
	By lblPermissionMessage = By.id("com.android.packageinstaller:id/permission_message");
	By btnDeny_ContactAccess = By.id("com.android.packageinstaller:id/permission_deny_button");
	
	By lblWelcomeToInstagram = By.id("com.instagram.android:id/field_title");

	public SignupPage GotoEmailAddressSection()
	{
		verifyMyElementDisplay(hdrEmailAddres, "min", "Email Address Header");
		ClickElement(hdrEmailAddres, "min", "Email Address Header");
		return new SignupPage(driver);
	}
	
	public SignupPage ValidateSignupElements_Email()
	{
		try
		{
			verifyMyElementDisplay(txtEmail, "min", "Email TextBox");
			verifyMyElementDisplay(btnNext, "min", "Next Button");
		}
		catch(Exception e)
		{
			Reporter.log("Exception in ValidateSignupElements");
		}
		return new SignupPage(driver);
	}
	
	
	
	public SignupPage Signup_With_Email(String strEmail, String FullName, String Password)
	{
		try
		{
			GotoEmailAddressSection();
			
			ClickElement(hdrEmailAddres, "min", "Email Address Header");
			if(verifyMyElementDisplay(txtEmail, "min", "Email TextBox"))
			{
				Test.log(LogStatus.PASS,Test.addScreenCapture(captureScreenshot(driver))+ "Email text box is displayed");
				SendKeysToElement(txtEmail, "min", strEmail, "Email TextBox");
				ClickElement(btnNext, "min", "Next Button");
				verifyMyElementDisplay(hdrEnterConfirmationCode, "min", "Confirmation code Header");
				String strConfirmationCode="851609";
				SendKeysToElement(txtEnterConfirmationCode, "min", strConfirmationCode, "Confirmation code TextBox");
				ClickElement(btnNext, "min", "Next Button");
				if(verifyMyElementDisplay(txtFullname, "min", "Full Name Textbox"))
				{
					SendKeysToElement(txtFullname, "min", FullName, "Full Name TextBox");
					verifyMyElementDisplay(txtPassword, "min", "Password Textbox");
					SendKeysToElement(txtPassword, "min", Password, "Password TextBox");
					ClickElement(btnNext, "min", "Continue and Sync Contacts Button");
					if(verifyMyElementDisplay(lblPermissionMessage, "min", "Permission Message"))
					{
						ClickElement(btnDeny_ContactAccess, "min", "Deny - Allow Permission to sync Contacts");
						Sign_FillBirthday();
						verifyMyElementDisplay(lblWelcomeToInstagram, "min", "Welcome to Instagram Message");
					}
				}
			}
			else
			{
				Test.log(LogStatus.FAIL,Test.addScreenCapture(captureScreenshot(driver))+ "Email textbox is not found");
			}
			
			
		}
		catch(Exception e)
		{
			Reporter.log("Exception in VerifySignupLink");
		}
		return new SignupPage(driver);
	}
	
	public void Sign_FillBirthday()
	{
		List nameOfList = driver.findElementsById("android:id/numberpicker_input");
		driver.findElement(By.id(nameOfList.get(0).toString())).sendKeys("15");
		driver.findElement(By.id(nameOfList.get(1).toString())).sendKeys("May");
		driver.findElement(By.id(nameOfList.get(2).toString())).sendKeys("1990");
	}
	
}
