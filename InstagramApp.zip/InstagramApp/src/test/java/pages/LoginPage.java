package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class LoginPage extends BasePage{

	public LoginPage(AppiumDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}


	By btnLogin = By.id("com.instagram.android:id/button_text");
	By txtUsername = By.id("com.instagram.android:id/login_username");
	By txtPassword = By.id("com.instagram.android:id/password");
	By lnkForgotPassword = By.id("com.instagram.android:id/login_forgot_button");

	/**Page Methods*/
    public LoginPage Login(String username, String password) {
    	try
		{
			System.out.println("inside Login Page method");
			
			if(verifyMyElementDisplay(btnLogin, "min", "Login button"))
			{
				Test.log(LogStatus.PASS,Test.addScreenCapture(captureScreenshot(driver))+ "Login screen is displayed");
				Reporter.log("Login screen is displayed");
				SendKeysToElement(txtUsername, "min", username, "Username TextBox");
				SendKeysToElement(txtPassword, "min", password, "Password TextBox");
				ClickElement(btnLogin, "min", "Login Button");
			}		
		}
		catch(Exception e)
		{
			Reporter.log("Exception in Login");
		}
        return this;
    }
    
    public LoginPage VerifyUsernameFieldDisplay() {
    	verifyMyElementDisplay(txtUsername, "min", "Login Screen - Username Field");
    	verifyMyElementDisplay(txtPassword, "min", "Login Screen - Password Field");
        return this;
    }
    
    public ForgotPasswordPage VerifyForgotPasswordLink() {    	
    	verifyMyElementDisplay(lnkForgotPassword, "min", "ForgotPassword link");    	
        return new ForgotPasswordPage(driver);
    }
    
    public ForgotPasswordPage GoToResetPasswordPage() {
    	ClickElement(lnkForgotPassword, "min", "ForgotPassword link");  
        return new ForgotPasswordPage(driver);
    }
    
}
