package testcases;

import java.lang.reflect.Method;

import org.testng.annotations.Test;

import pages.SignupPage;

public class SignupTest extends CommonTest{

	
	@Test(priority = 1, description = "Signup for a new account", enabled = true)

    public void Signup(Method method) { 
		System.out.println("Inside Signup Test");
		landingPage
		.VerifyLaunchApp()
        .GoToSignupPage()
        .Signup_With_Email("karthikg1515@gmail.com", "Karthik", "TestPassword");
    }
	
	@Test(priority = 0, description = "Validate signup screen", enabled = false)

    public void ValidateSingupPage(Method method) { 
		System.out.println("Inside ValidateSingupPage Test");
		landingPage
		.VerifyLaunchApp()
        .GoToSignupPage();
		signupPage
		.GotoEmailAddressSection()
        .ValidateSignupElements_Email();
    }
	
}
