package testcases;

import java.lang.reflect.Method;

import org.testng.annotations.Test;

import pages.ForgotPasswordPage;

public class ForgotPasswordTest extends CommonTest {

	@Test(priority = 0, description = "Validate Forgot password functionality - Email", enabled= false)	

    public void ResetMyPassword_Email(Method method) { 
		landingPage
		.VerifyLaunchApp()
        .GoToLoginPage();
		loginPage
		.GoToResetPasswordPage();
        forgotPasswordPage
        .ResetMyPassword_Email("test@gmail.com");
    }
	
	@Test(priority = 1, description = "Validate Forgot password functionality - SMS", enabled= true)	

    public void ResetMyPassword_SMS(Method method) { 
		landingPage
		.VerifyLaunchApp()
        .GoToLoginPage();
		loginPage
		.GoToResetPasswordPage();
        forgotPasswordPage
        .ResetMyPassword_SMS("test@gmail.com");
    }
	
	@Test(priority = 0, description = "Validate Forgot password functionality", enabled= false)	

    public void ValidateForgotMyPasswordFields(Method method) { 
		landingPage
		.VerifyLaunchApp()
        .GoToLoginPage();
		loginPage
		.GoToResetPasswordPage();
        forgotPasswordPage
        .VerifyFindYourAccountFieldDisplay();
    }

}
