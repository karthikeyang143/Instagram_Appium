package testcases;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.google.common.io.Files;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import pages.BasePage;
import pages.ForgotPasswordPage;
import pages.LandingPage;
import pages.LoginPage;
import pages.SignupPage;

public class CommonTest{

	//public WebDriver driver;
//  	public static ExtentTest Test;
//  	public static ExtentReports Report;
    public static LandingPage landingPage;
    public static SignupPage signupPage;
    public static LoginPage loginPage;
    public static ForgotPasswordPage forgotPasswordPage;
    
    //BasePage basePage = new BasePage(driver);
    
    AppiumDriver driver = BasePage.driver;
    ExtentTest Test  = BasePage.Test;
    ExtentReports Report = BasePage.Report;
 
    @BeforeClass
    public void Setup() { 
    
    	BasePage.AppiumSetup();    	
    }
 
    @BeforeMethod
    public void methodLevelSetup() {
    	landingPage = new LandingPage(BasePage.driver);
    	landingPage = new LandingPage(BasePage.driver);
    	loginPage = new LoginPage(BasePage.driver);
    	forgotPasswordPage = new ForgotPasswordPage(BasePage.driver);
    }
 
    @BeforeSuite
   	public void startMyExtentReport()
   	{
    	BasePage.startExtentReport();
   	}    
    
    @AfterSuite
    public void teardown() {
    	BasePage.endMyTest();
    }
    

	public static String captureScreenshot(WebDriver driver) throws IOException {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File Dest = new File("test-output/Screenshots/" + System.currentTimeMillis()+".png");
		String errflpath = Dest.getAbsolutePath();
		Files.copy(scrFile, Dest);
		return errflpath;
	}
	
    public boolean verifyMyElementDisplay(By obj, String waitTime, String objNameForReport)
    {
		boolean flag=false;
    	try
		{
			if(dwn_sub_intelligentWait(obj, waitTime, objNameForReport))
			{
				Test.log(LogStatus.PASS,Test.addScreenCapture(captureScreenshot(driver))+ objNameForReport +" is available");
				Reporter.log(objNameForReport +" is available");
				System.out.println(objNameForReport +" is available");
				flag=true;
			}
			else
			{
				Test.log(LogStatus.FAIL,Test.addScreenCapture(captureScreenshot(driver))+ objNameForReport +" is NOT available");
				Reporter.log(objNameForReport +" is NOT available");
				System.out.println(objNameForReport +" is NOT available");
			}
		}
		catch(Exception e)
		{
			Reporter.log("Exception in verifyMyElementDisplay "+e.getMessage());
		}
    	return flag;
    }
    
    public boolean ClickElement(By obj, String waitTime, String objNameForReport)
    {
    	boolean flag=false;
    	
    	try
		{
			if(dwn_sub_intelligentWait(obj, waitTime, objNameForReport))
			{
				driver.findElement(obj).click();
				Test.log(LogStatus.PASS, "Clicked on "+objNameForReport);
				flag=true;
			}
			else
			{
				Test.log(LogStatus.FAIL,Test.addScreenCapture(captureScreenshot(driver))+ objNameForReport +" is NOT available");
			}
		}
		catch(Exception e)
		{
			Reporter.log("Exception in ClickElement "+e.getMessage());
		}
    	return flag;
    }
    
    public boolean SendKeysToElement(By obj, String waitTime, String strText, String objNameForReport)
    {
    	boolean flag=false;
    	if(verifyMyElementDisplay(obj, waitTime, objNameForReport))
    	{
    		driver.findElement(obj).sendKeys(strText);
    		Test.log(LogStatus.PASS, "Sendkeys succes, object:"+objNameForReport+", text:"+strText);
    	}
    	return flag;
    }
    
    /*
	 *******************************************************************************
	 * @Project Name : Project Name
	 * @Function Name : dwn_sub_intelligentWait_WithoutFrame()
	 * @Description : To wait for an element till given time
	 * @Input Param : element, waitTime, reportName
	 * @Return : true or false
	 * @Date : DD-MM-YYYY
	 * @Author :  Karthik
	 *******************************************************************************
	 */
	public Boolean dwn_sub_intelligentWait(By bjObj, String strWait, String reportObjName)
	{
		return dwn_sub_intelligentWait_Internal(bjObj, strWait, reportObjName);
	}
	
	/*
	 *******************************************************************************
	 * @Project Name : Instagram Automation
	 * @Function Name : dwn_sub_intelligentWait()
	 * @Description : To wait for an element display until the given time
	 * @Input Param : Element, int waitSeconds, reportObjName
	 * @Return : NA
	 * @Date : 23/04/2021
	 * @Author :  Karthik
	 *******************************************************************************
	 */
	public Boolean dwn_sub_intelligentWait_Internal(By byObj, String strWait, String reportObjName)
	{
		Boolean flag=false;
		int waitSeconds=0;
		try
		{
			waitSeconds=dwn_sub_getWaitTimeInSeconds(strWait);
			//			System.out.println("======intelligentWait_Internal-waitSeconds :"+waitSeconds);
			for (int i = 1; i <= waitSeconds; i++)
			{
				try {
					if (driver.findElement(byObj).isDisplayed()) {
						flag = true;
						break; //Break the loop if element found
					}
					
					
				} catch (Exception ex) {
					flag = false;
					Thread.sleep(1000);
				}
			}
		}
		catch (Exception e)
		{			
			e.printStackTrace();
		}
		return flag;
	}
	
	/*
	 *******************************************************************************
	 * @Project Name : Project Name
	 * @Function Name : getWaitTimeInSeconds()
	 * @Description : To get wait time in seconds from given string
	 * @Input Param : strWait
	 * @Return : waitSeconds
	 * @Date : DD-MM-YYYY
	 * @Author :  Karthik
	 *******************************************************************************
	 */
	public int dwn_sub_getWaitTimeInSeconds(String strWait)
	{
		int waitSeconds=0;
		//		System.out.println("======wait seconds- strWait:"+strWait);
		if((strWait.equalsIgnoreCase("min"))||(strWait.equalsIgnoreCase("medium"))||(strWait.equalsIgnoreCase("max"))||strWait.equalsIgnoreCase("supermax")||strWait.equalsIgnoreCase("ultramax")||strWait.equalsIgnoreCase("low"))
		{
			strWait=strWait.toUpperCase();
			switch (strWait)
			{
			case "MIN":
				waitSeconds=10;
				break;
			case "MEDIUM":
				waitSeconds=20;
				break;
			case "MAX":
				waitSeconds=30;
				break;
			case "SUPERMAX":
				waitSeconds=60;
				break;
			case "ULTRAMAX":
				waitSeconds=90;
				break;
			case "LOW":
				waitSeconds=2;
				break;
			default:
				waitSeconds=5;
				break;
			}
		}
		else {
			try {
				waitSeconds = Integer.parseInt(strWait);
			} catch (Exception e) {				
				System.out.println("Exception in Get Waittime");
			}
		}
		return waitSeconds;
	}
  
}
