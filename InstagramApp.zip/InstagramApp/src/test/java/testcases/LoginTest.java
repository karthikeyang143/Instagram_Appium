package testcases;

import java.lang.reflect.Method;

import org.testng.annotations.Test;

public class LoginTest extends CommonTest {

	@Test(priority = 0, description = "Login with existing valid username and password")	

    public void Login(Method method) { 
		landingPage
		.VerifyLaunchApp()
        .GoToLoginPage();
        loginPage
        .Login("test@gmail.com", "************");
    }
	
	@Test(priority = 0, description = "Login with existing valid username and password")	

    public void VerifyLoginScreenFields(Method method) { 
		landingPage
		.VerifyLaunchApp()
        .GoToLoginPage();
        loginPage
        .VerifyUsernameFieldDisplay()
        .VerifyForgotPasswordLink();
    }
}
